<?php
include('php/admin_login.php'); 

if(isset($_SESSION['login_admin'])){
header("location:adminhome.php"); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style2.css">
    <title>Dream Explora | Login</title>
</head>
<body>
      <div class="container">
        <div class="box form-box">
         

            <img src="images/dreamexploralogo.png" width="120px" length="120" alt="Centered Image" style="display: block; margin: 0 auto;">
            <div style="padding-bottom: 10px;"></div>
            <header>Admin Login</header>
            <form action="" method="post">
                <div class="field input">
                    <label for="email">Email</label>
                    <input type="text" name="email" id="email" autocomplete="off" required>
                </div>

                <div class="field input">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" autocomplete="off" required>
                </div>

                <div class="field">
                    
                    <input type="submit" class="btn" name="submit" value="Login" required>
                </div>
                
            </form>
        </div>

      </div>
</body>
</html>