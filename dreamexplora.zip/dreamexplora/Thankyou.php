<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Booking Success</title>
<link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Source+Sans+Pro" rel="stylesheet">
<link href="css/thankyou-page.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class=content>
  <div class="wrapper-1">
    <div class="wrapper-2">
      <h1>Thank you !</h1>
		<p><?php if(isset($_GET['noti'])){ 
			   echo $_GET['noti']; 
		     } ?> </p>
      <p>Thanks for using our services!</p>
      <p>Enjoy your trip!</P>
      
		<br>
      <a class="go-home" href="mybooking.php"> my booking </a>
    </div>
    
</div>
</div>




</body>
</html>
