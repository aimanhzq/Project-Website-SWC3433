<?php
require 'connection.php';
$conn = Connect();

$sql = "SELECT * FROM customer";
$result = mysqli_query($conn, $sql);
	
		$username =  $_POST['username'];
        $email = $_POST['email'];
        $age =  $_POST['age'];
        $password = $_POST['password'];

$rule = "SELECT * FROM customer WHERE email = '$email'";
$verify_query = mysqli_query($conn,$rule);

if(mysqli_num_rows($verify_query) !=0 ){
            $em = "This email is used, Try another One Please!";
            header("Location: ../register.php?noti=$em");

}

else {
	
$query = "INSERT INTO customer(username,email,age,password) VALUES('" . $username . "','" . $email . "','" . $age ."','" . $password . "')";
$success = $conn->query($query);	
	
	
	$em="Registration success!";
	header("Location: ../register.php?noti=$em");
	$conn->close();}


?>