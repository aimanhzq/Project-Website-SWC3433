<?php
include('php/session_customer.php');
$id_session =$row['customer_id'];


if(!isset($login_session)){
header('Location:login.php'); // Redirecting To Home Page
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Dream Explora | My Booking</title>

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <link href="css/mybooking.css" rel="stylesheet" type="text/css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   <script>
      $(document).ready(function(){
          $(".scroll-top").click(function() {
              $("html, body").animate({ 
                  scrollTop: 0 
              }, "slow");
              return false;
          });
      });
   </script>

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo"><img src="images/dreamexploralogo.png" width="120px" length="120px"></a>

   <nav class="navbar">
	  <a class="active">Welcome, <?php echo $login_session; ?></a>
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="package.php">packages</a>
	   <a href="logout.php">log out</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<div class="heading" style="background:url(images/header-bg-2.png) no-repeat">
   <h1>MY BOOKING</h1>
</div>
 
<div class="box-container">
<ul class="cards">
	
<?php

// Storing Session
$conn = Connect();
$sql = "SELECT 
		booking.booking_id,booking.guest,booking.arrival,booking.leaving,
		customer.username,
		packages.name, packages.price,packages.picture_path 
		FROM ((booking
		INNER JOIN packages ON booking.package_id = packages.package_id)
		INNER JOIN customer ON booking.customer_id = customer.customer_id)
		WHERE booking.customer_id = $id_session";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)	
{ 	

//OUTPUT DATA OF EACH ROW
while($row = mysqli_fetch_assoc($result)){
?>	
	
  <li class="cards__item">
    <div class="card">
      <img class="card__image" src="images/<?php echo $row["picture_path"]; ?>">
      <div class="card__content">
        <div class="card__title"><?php echo $row["name"]; ?> || <?php echo $row["username"]; ?></div>
        <p class="card__text">
		 Guest : <?php echo $row["guest"]; ?><br> 
		 Arrival : <?php echo $row["arrival"]; ?><br>
		 Leaving : <?php echo $row["leaving"]; ?><br>
		 Price : RM <?php echo $row["price"]; ?>
		 </p>
        <a class="btn btn--block card__btn" href="bookingdelete.php?id=<?php echo $row["booking_id"];?>">Cancel</a>
      </div>
    </div>
  </li>
<?php }} ?>
		
	

	
</ul>
</div>
</body>
</head>

