<?php
$packageid = $_GET['packageid'];
require 'php/session_customer.php';
$id_session =$row['customer_id'];
$conn = Connect();
$sql = "SELECT * FROM packages WHERE package_id =$packageid";
$result = mysqli_query($conn, $sql);
	
		$customerid = $id_session;
        $packageid = $_GET['packageid'];
        $guests = $_POST['guests'];
      	$arrivals = $_POST['arrivals'];
      	$leaving = $_POST['leaving'];

$query = "INSERT INTO booking(customer_id,package_id,guest,arrival,leaving) VALUES('" . $customerid . "','" . $packageid . "','" . $guests ."','" . $arrivals . "','" . $leaving . "')";
$success = $conn->query($query);	
	
	
	$em="Booking success!";
	header("Location:Thankyou.php?noti=$em");
	$conn->close();
      

    
?>