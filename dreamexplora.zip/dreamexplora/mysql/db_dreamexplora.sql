-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2024 at 01:13 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_dreamexplora`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'admin@admin.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `guest` int(11) NOT NULL,
  `arrival` date NOT NULL,
  `leaving` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `customer_id`, `package_id`, `guest`, `arrival`, `leaving`) VALUES
(1, 123, 1, 12, '2024-04-06', '2024-04-30'),
(8, 128, 6, 69, '2024-09-06', '2025-09-06'),
(14, 126, 1, 1, '2024-04-01', '2024-04-01');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `username`, `email`, `age`, `password`) VALUES
(123, 'Afif', 'afif@gmail.com', 13, 'afiflovecock'),
(125, 'Afif', '123', 12, '123456'),
(126, 'Muqries', 'hasrizalmuqries@gmail.com', 12, '12345'),
(127, 'Muqries', 'muqriescute@gmail.com', 12, '123'),
(128, 'AfifPussySlayer', 'ilovecock@gmail.com', 69, 'sasugay');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `package_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `detail` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `picture_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`package_id`, `name`, `detail`, `price`, `picture_path`) VALUES
(1, 'Dubai Tour Packages', 'Enjoy the Emirates with unforgettable fun with our Dubai top selling packages!', '470.00', 'dubai.jpg'),
(2, 'Delhi Tour Packages', 'Enjoy the Emirates with unforgettable fun with our Delhi top selling packages!', '427.00', 'delhi.jpg'),
(3, 'London Tour Packages', 'Enjoy the Emirates with unforgettable fun with our Japan top selling packages!', '514.00', 'london.jpg'),
(4, 'Australia Tour Packages', 'Enjoy the Emirates with unforgettable fun with our Australia top selling packages!', '600.00', 'australia.jpg'),
(5, 'china Tour Packages', 'Enjoy the Emirates with unforgettable fun with our China top selling packages!', '340.00', 'china.jpg'),
(6, 'singapore Tour Packages', 'Enjoy the Emirates with unforgettable fun with our Singapore top selling packages!', '557.00', 'singapore.jpg'),
(7, 'Digital World', 'THE Digital World is a pseudo-cyberspace located on the network, where Digimon and other digital lifeforms inhabit.', '999.00', 'digital world-nJr.png'),
(8, 'canada Tour Packages', 'Enjoy the Emirates with unforgettable fun with our Canada top selling packages!', '946.00', 'canada.jpg'),
(9, 'bali Tour Packages', 'Enjoy the Emirates with unforgettable fun with our Bali top selling packages!\r\n           ', '643.00', 'bali.jpg'),
(10, 'nepal Tour Packages', 'Enjoy the Emirates with unforgettable fun with our Nepal top selling packages!', '341.00', 'nepal.jpg'),
(11, 'bangladesh Tour Packages', 'Enjoy the Emirates with unforgettable fun with our Bangladesh top selling packages!', '255.00', 'bangladesh.jpg'),
(13, 'Digital Beach', 'BITCH', '200.00', 'Digimonbeach.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `customer_id` (`customer_id`) USING BTREE,
  ADD KEY `package_id` (`package_id`) USING BTREE;

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`package_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `package_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `packages` (`package_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
