<?php
session_start();
include('php/connection.php');
$conn = Connect();
$sql = "DELETE FROM booking WHERE booking_id='" . $_GET["id"] . "'";
if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);
header('Location: bookinglist.php');
?>
